/*****************************************************
This is a sample of what the main should like for the first phase of the
Mancala game.
	John Dolan	Ohio University		Spring 2019
*************************************************************/

#include "othello.h"
#include <iostream>
using namespace std;
using namespace main_savitch_14;


int main(){
   othello reversi;
   reversi.play();
   return 0;
}